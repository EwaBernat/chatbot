# Seria „Teoria umysłu" — opisy do sklepu internetowego

Autorka: **Mirosława Ewa Jurczyszyn**, pedagog specjalny · terapeuta ·
autorka materiałów do edukacji i terapii, PCTP Koszalin.
Kontakt: **kontakt@eduplaner2026.pl**

Trzy pozycje do sprzedaży osobno albo w pakiecie. Wszystkie w formacie PDF A4,
gotowe do druku, z osadzonymi krojami pisma (otwierają się identycznie na każdym
komputerze). Poniżej gotowe teksty do wklejenia w karty produktów.

---

## Produkt 1 — Teoria umysłu a funkcjonowanie dziecka, ucznia z autyzmem

**Nazwa w sklepie:** Teoria umysłu a funkcjonowanie dziecka i ucznia z autyzmem — część 1: Ogólna
**Plik:** `Teoria-umyslu-1-Ogolna.pdf` · **24 strony A4** · ok. 4,6 MB
**Okładka do karty produktu:** `okladka-czesc-1.png`

### Opis krótki (do listingu, ok. 300 znaków)

Poradnik dla nauczycieli, terapeutów i rodziców dzieci oraz uczniów w spektrum autyzmu.
Etapy rozwoju teorii umysłu, normy wiekowe, testy, cztery poziomy funkcjonowania
i dostosowania zgodne z przepisami. 18 gotowych ćwiczeń oraz karta obserwacji do druku.

### Opis długi (do karty produktu)

Teoria umysłu decyduje o tym, czy dziecko rozumie, że inni ludzie myślą i czują coś
innego niż ono samo. Bez tej umiejętności nie działa ani nauka na lekcji, ani zabawa
z rówieśnikami. Ta część serii pokazuje, jak rozpoznać poziom funkcjonowania dziecka
i co z tym zrobić w przedszkolu i w szkole.

W środku:

- definicja i trzy filary: emocje (TUE), przekonania (TUK), działanie społeczne (TUS)
  — z wyjaśnieniem, co ćwiczyć najpierw i dlaczego kolejność ma znaczenie
- etapy rozwoju z normami wiekowymi: od 0 do 6 lat oraz uczeń i osoba dorosła
- sześć mechanizmów powstawania trudności, z uwzględnieniem problemu podwójnej empatii
- listy obserwacyjne dla przedszkola i szkoły
- testy i narzędzia oceny wraz z wyraźną granicą: co wolno nauczycielowi, a co psychologowi
- cztery poziomy funkcjonowania i priorytet pracy na każdym z nich
- gotowe formuły zapisu do WOPFU i celów do IPET, z kryterium nadającym się do oceny
- podstawa prawna: kształcenie specjalne i pomoc psychologiczno-pedagogiczna
- dostosowanie przekazu słownego i lektur — tabela „zamiast → powiedz" i pięć technik
- **18 gotowych ćwiczeń** rozpisanych krok po kroku, od przedszkola po szkołę ponadpodstawową
- przykładowy program „Widzę – Myślę – Rozumiem" na 30 spotkań
- **karta obserwacji teorii umysłu do druku** — formularz do WOPFU

### Dla kogo

Nauczyciele przedszkoli i szkół, nauczyciele współorganizujący kształcenie specjalne,
pedagodzy specjalni, terapeuci, psycholodzy szkolni, rodzice.

### Słowa kluczowe

teoria umysłu, autyzm, spektrum autyzmu, WOPFU, IPET, kształcenie specjalne,
pomoc psychologiczno-pedagogiczna, mentalizowanie, fałszywe przekonanie,
zajęcia rewalidacyjne, karta obserwacji, ćwiczenia dla dzieci z autyzmem

---

## Produkt 2 — Cztery emocje i wspólna uwaga (część 2A)

**Nazwa w sklepie:** Program teorii umysłu dla przedszkola — część 2A: pierwsze pół roku
**Plik:** `Teoria-umyslu-2A-przedszkole.pdf` · **30 stron A4** · ok. 5,0 MB
**Okładka do karty produktu:** `okladka-czesc-2A.png`

### Opis krótki

Gotowy sześciomiesięczny program zajęć teorii umysłu dla dziecka z autyzmem w przedszkolu.
48 spotkań, 12 scenariuszy, opowiadania, karty pracy, cele SMART do IPET
i trzy załączniki do wycięcia: termometr emocji, karty emocji i karty „czuje się… bo…".

### Opis długi

Program dla dziecka w wieku przedszkolnym, rozpisany na sześć miesięcy i 48 spotkań
po 30 minut, dwa razy w tygodniu. Zaczyna się od diagnozy wstępnej, która mówi,
od którego miesiąca zacząć — a kończy zapisami gotowymi do przepisania do dokumentacji.

W środku:

- diagnoza wstępna: dziesięć prób obserwacyjnych na arkuszu do druku
- sześć modułów miesięcznych: wspólne pole uwagi → cztery emocje → przyczyna emocji
  („bo…") → różne pragnienia → perspektywa wzrokowa → wiedza i zdziwienie
- każdy moduł ma cel, kryterium przejścia dalej i listę materiałów
- **12 scenariuszy zajęć** rozpisanych zdanie po zdaniu, z wersją łatwiejszą i trudniejszą
- 6 opowiadań z pytaniami oraz zestaw bajek, które dzieci już znają
- 3 karty pracy do druku
- wyprawka: co przygotować na całe pół roku
- **6 celów SMART z kryterium**, gotowych do przepisania do IPET
- zapisy do WOPFU, dostosowania i podstawa prawna
- karta monitorowania efektów
- sześć zadań dla rodziców do przekazania do domu
- **trzy załączniki A4 do zabawy i terapii:** termometr emocji na ścianę,
  pięć dużych twarzy do wycięcia i dwanaście kart „czuje się… bo…"

### Dla kogo

Nauczyciele przedszkoli, nauczyciele współorganizujący, terapeuci prowadzący
zajęcia rewalidacyjne i zajęcia z zakresu pomocy psychologiczno-pedagogicznej, rodzice.

### Słowa kluczowe

teoria umysłu przedszkole, program zajęć autyzm, emocje podstawowe, wspólne pole uwagi,
scenariusze zajęć, karty pracy, IPET cele SMART, rewalidacja przedszkole,
termometr emocji, karty emocji do druku

---

## Produkt 3 — Emocje złożone i zabawa razem (część 2B)

**Nazwa w sklepie:** Program teorii umysłu dla przedszkola — część 2B: drugie pół roku
**Plik:** `Teoria-umyslu-2B-przedszkole.pdf` · **32 strony A4** · ok. 5,5 MB
**Okładka do karty produktu:** `okladka-czesc-2B.png`

### Opis krótki

Kontynuacja programu: kolejne 48 spotkań o emocjach złożonych, regulacji i zabawie
z rówieśnikiem. 12 scenariuszy, wzory sprawozdań z rewalidacji i z pomocy
psychologiczno-pedagogicznej, 48 wpisów do dziennika i trzy załączniki do wycięcia.

### Opis długi

Druga połowa rocznego programu. Zaczyna się tam, gdzie dziecko zna już cztery emocje
podstawowe, a wciąż nie umie bawić się z innymi. Sześć modułów prowadzi od dumy i wstydu
przez regulację emocji do rozróżnienia „chciał czy niechcący".

W środku:

- próba kontrolna po pierwszym półroczu i mapa sześciu modułów
- moduły: duma i wstyd → zazdrość, zawód, tęsknota → regulacja emocji →
  zabawa symboliczna → wejście do zabawy z rówieśnikiem → intencja a skutek
- **12 scenariuszy zajęć** i 4 opowiadania z pytaniami i wskazówkami
- 2 karty pracy oraz trzy narzędzia ilustrowane: koło emocji, gra „Ścieżka emocji",
  karty sytuacji
- **czym różnią się zajęcia rewalidacyjne od zajęć z zakresu pomocy
  psychologiczno-pedagogicznej** — merytorycznie i w papierach
- **dwa wzory sprawozdań półrocznych** (rewalidacja i PPP) plus przykład wypełniony
- **48 gotowych tematów do wpisania w dzienniku zajęć**
- 6 celów SMART do IPET i karta monitorowania
- **trzy załączniki A4:** koło emocji, plansza gry i karty sytuacji do wycięcia

### Dla kogo

Jak w części 2A. Część 2B zakłada, że część 2A jest za nami.

### Słowa kluczowe

emocje złożone, duma wstyd zazdrość, regulacja emocji, zabawa symboliczna,
zabawa z rówieśnikiem, intencja a skutek, wzór sprawozdania rewalidacja,
sprawozdanie pomoc psychologiczno-pedagogiczna, wpisy do dziennika zajęć,
koło emocji do druku

---

## Pakiet — cała seria

**Nazwa w sklepie:** Teoria umysłu — komplet trzech części
**Zawartość:** 3 pliki PDF, razem **86 stron A4**

### Opis

Komplet: podstawy teoretyczne z narzędziami oceny (część 1) plus gotowy roczny program
dla przedszkola rozpisany na 96 spotkań (części 2A i 2B). Części łączą się:
ten sam system kolorów emocji, ta sama struktura spotkania, ta sama dokumentacja.
Część 1 mówi **co i dlaczego**, części 2A i 2B — **co robić w poniedziałek o dziewiątej**.

---

## Sugerowana informacja o licencji

Do uzgodnienia z autorką — poniżej propozycja do ewentualnego użycia:

> Materiał przeznaczony do użytku własnego nabywcy: nauczyciela, terapeuty lub rodzica.
> Można drukować i powielać karty pracy oraz załączniki na potrzeby pracy z własnymi
> dziećmi i uczniami. Nie wolno odsprzedawać, udostępniać publicznie ani rozpowszechniać
> pliku PDF. Wszelkie prawa autorskie zastrzeżone — Mirosława Ewa Jurczyszyn, PCTP Koszalin.

## Zastrzeżenie merytoryczne (jest już w broszurach)

Materiały mają charakter informacyjno-metodyczny. Nie zastępują diagnozy specjalistycznej
ani wykładni przepisów prawa oświatowego. Przy powoływaniu się na akty prawne należy
sprawdzić aktualny tekst jednolity w ISAP.
